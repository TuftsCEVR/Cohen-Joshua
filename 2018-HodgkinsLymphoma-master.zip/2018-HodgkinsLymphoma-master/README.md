# 2018-HodgkinsLymphoma
Model for treatment of Early Stage Hodgkins Lymphoma using either (1) chemotherapy or (2) chemotherapy &amp; radiation
